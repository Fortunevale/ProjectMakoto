﻿namespace ProjectMakoto.Commands;

internal sealed class $safeitemname$ : BaseCommand
{
    public override Task ExecuteCommand(SharedCommandContext ctx, Dictionary<string, object> arguments)
    {
        return Task.Run(async () =>
        {

        });
    }
}